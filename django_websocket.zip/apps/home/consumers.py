
import json
from channels.generic.websocket import AsyncJsonWebsocketConsumer,JsonWebsocketConsumer, WebsocketConsumer
from channels.exceptions import StopConsumer
from . import ws_views




# class ChatConsumer(AsyncJsonWebsocketConsumer):
class ChatConsumer(WebsocketConsumer):
    def websocket_connect(self,message):
        # 客户端连接触发此方法
        self.accept()  # 接受连接
        self.send(text_data=json.dumps({'code': 200, 'type': 'open', 'msg': 'websocket 连接成功'}) )
        self.message_list=[]

    def websocket_receive(self, message):
        # 收发消息
        # print(message)
        msg_json = json.loads(message.get('text'))
        ws_views.handlerGet(self, msg_json)

        # await self.send_json({
        #     "code":200,
        #     "msg":f'消息已收到{self.count}',
        # })
        # self.count += 1

    def websocket_disconnect(self, message):
        # 关闭连接
        print('连接已断开')
        # ws_views.leaveChat(self)
        raise StopConsumer