
import json
from qianfan import Qianfan

client = Qianfan(

    # 方式一：使用安全认证AK/SK鉴权
    # 替换下列示例中参数，安全认证Access Key替换your_iam_ak，Secret Key替换your_iam_sk，如何获取请查看https://cloud.baidu.com/doc/Reference/s/9jwvz2egb
    access_key="71af8***7376",
    secret_key="1b4**2062a",
    # app_id="", # 选填，不填写则使用默认appid

    # 方式二：使用应用BearerToken鉴权
    # 替换下列示例中参数，将your_BearerToken替换为真实值，如何获取请查看https://cloud.baidu.com/doc/IAM/s/Mm2x80phi
    # api_key="your_BearerToken"
    # app_id="", # 选填，不填写则使用默认appid
)




def handlerGet(websocket, msg):
    # print(websocket)
    # print(msg.get('msg'))
    # return
    message = {'role': 'user', 'content': msg.get('msg')}

    websocket.message_list.append(message)

    completion = client.chat.completions.create(
        # model="ernie-3.5-8k",  # 指定特定模型
        model="ernie-4.0-8k",  # 指定特定模型
        messages=websocket.message_list,
        stream=True
    )

    results = ''

    websocket.send(text_data=json.dumps({'code': 200, 'type': 'ai_start', 'msg': ''}))
    for r in completion:
        msg = r.choices[0].delta.content
        results += msg
        websocket.send(text_data=json.dumps({'code': 200, 'type': 'ai', 'msg': msg}))

    websocket.send(text_data=json.dumps({'code': 200, 'type': 'ai_end', 'msg': ''}))
    sys_msg = {'role':'assistant', 'content': results}
    websocket.message_list.append(sys_msg)