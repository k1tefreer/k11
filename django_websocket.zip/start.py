
import os
from pathlib import Path

def main():
    os.system(f'python manage.py runserver 0.0.0.0:2247')

if __name__ == '__main__':
    main()